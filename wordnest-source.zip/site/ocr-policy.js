(function(root){
  const normalize=text=>text.replace(/^[^A-Za-z]+|[^A-Za-z]+$/g,'').replace(/[’‘]/g,"'").toLowerCase();
  function collect(passes,spell){
    const words=new Map();
    passes.forEach((data,pass)=>{for(const w of data.words||[]){
      const text=normalize(w.text);
      if(!/^[a-z]+(?:['-][a-z]+)*$/.test(text)||text.length<2||['adj','adv','vt','vi'].includes(text))continue;
      let entry=words.get(text);if(!entry)words.set(text,entry={text,confidence:0,passes:new Set()});
      entry.confidence=Math.max(entry.confidence,w.confidence);if(w.confidence>=65)entry.passes.add(pass);
    }});
    return [...words.values()].map(w=>({text:w.text,confidence:w.confidence,known:spell.correct(w.text),agreed:w.passes.size>=2})).filter(w=>w.confidence>=45).map(w=>({...w,uncertain:!(w.known&&(w.agreed||w.confidence>=92))}));
  }
  const api={collect};if(typeof module!=='undefined')module.exports=api;else root.OCRPolicy=api;
})(globalThis);
