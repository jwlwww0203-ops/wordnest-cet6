const CACHE='shici-v6';
const CORE=['styles.css?v=6','app.js?v=6','word-lookup.js?v=6','ocr-layout.js?v=4','ocr-policy.js?v=4','vendor/dictionary/nspell.js?v=4','vendor/dictionary/index.aff','vendor/dictionary/index.dic','manifest.webmanifest','assets/icon.svg'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('shici-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
  const url=new URL(e.request.url);
  if(e.request.method!=='GET'||url.origin!==self.location.origin||e.request.mode==='navigate')return;
  if(/\/lexicon\/[a-z][a-z_]\.json$/.test(url.pathname)){
    e.respondWith(caches.open(CACHE).then(async cache=>{
      const cached=await cache.match(e.request);if(cached)return cached;
      const response=await fetch(e.request);if(response.ok&&response.type==='basic'&&!response.redirected)await cache.put(e.request,response.clone());return response;
    }));return;
  }
  if(!CORE.some(p=>new URL(p,self.registration.scope).pathname===url.pathname))return;
  e.respondWith(fetch(e.request).then(async r=>{if(r.ok&&r.type==='basic'&&!r.redirected){const cache=await caches.open(CACHE);await cache.put(e.request,r.clone())}return r}).catch(()=>caches.match(e.request).then(r=>r||Response.error())));
});
