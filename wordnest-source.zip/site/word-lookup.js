(function(root){
  const pending=new Map();
  async function json(url,timeout=8000){
    const controller=new AbortController();let timer;
    try{return await Promise.race([
      fetch(url,{signal:controller.signal}).then(r=>{if(!r.ok)throw Error(r.status===404?'missing':'network');return r.json()}),
      new Promise((_,reject)=>{timer=setTimeout(()=>{controller.abort();reject(Error('timeout'))},timeout)})
    ])}finally{clearTimeout(timer)}
  }
  function load(word){
    word=word?.toLowerCase()||'';
    if(!/^[a-z]/.test(word))return Promise.resolve({});
    const letter=word[0]+(/^[a-z]$/.test(word[1]||'')?word[1]:'_');
    if(!pending.has(letter))pending.set(letter,json('lexicon/'+letter+'.json?v=6').then(data=>{
      if(!data||typeof data!=='object'||Array.isArray(data)||!Object.values(data).every(e=>typeof e.meaning==='string'))throw Error('invalid');return data;
    }).catch(()=>{pending.delete(letter);throw Error('local-network')}));
    return pending.get(letter);
  }
  function local(data,word){return Object.prototype.hasOwnProperty.call(data,word)?data[word]:null}
  async function find(word){
    const data=await load(word);const entry=local(data,word);if(entry)return {...entry};
    // Outside the bundled vocabulary, show an explicitly English definition.
    // Never fabricate a sentence when the provider supplies none.
    let result;
    try{result=await json('https://api.dictionaryapi.dev/api/v2/entries/en/'+encodeURIComponent(word),6000)}
    catch(e){throw Error(e.message==='missing'?'missing':'missing-offline')}
    for(const d of result){
      for(const m of d.meanings||[]){
        const def=m.definitions?.find(x=>x.definition&&x.example)||m.definitions?.find(x=>x.definition);
        if(def)return {part:m.partOfSpeech||'word',phonetic:d.phonetic||d.phonetics?.find(p=>p.text)?.text||'',meaning:'英文释义：'+def.definition,sceneEn:def.example||'',sceneZh:def.example?'词典原例句，暂无中文译文。':'',audio:d.phonetics?.find(p=>p.audio)?.audio||'',source:'dictionaryapi'};
      }
    }
    return null;
  }
  root.WordLookup={load,local,find};
})(globalThis);
