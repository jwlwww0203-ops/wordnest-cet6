/* Geometry only: never guesses vocabulary or substitutes recognized spellings. */
(function(root){
  const median=a=>[...a].sort((a,b)=>a-b)[Math.floor(a.length/2)]||0;
  function columns(words,width){
    const anchors=words.filter(w=>/^[A-Za-z]{3,}$/.test(w.text)&&w.confidence>=75&&w.bbox.y1-w.bbox.y0>=10);
    const groups=[];
    for(const w of anchors.sort((a,b)=>a.bbox.x0-b.bbox.x0)){
      let group=groups.find(g=>Math.abs(median(g.map(v=>v.bbox.x0))-w.bbox.x0)<Math.max(15,width*.025));
      if(!group)groups.push(group=[]);group.push(w);
    }
    return groups.filter(g=>g.length>=3&&new Set(g.map(w=>Math.round(w.bbox.y0/30))).size>=3).map(g=>{
      const height=median(g.map(w=>w.bbox.y1-w.bbox.y0));
      const left=median(g.map(w=>w.bbox.x0));
      const aligned=words.filter(w=>Math.abs(w.bbox.x0-left)<Math.max(15,width*.025)&&w.bbox.x1-w.bbox.x0<width*.55);
      return {x0:Math.max(0,Math.floor(Math.min(...g.map(w=>w.bbox.x0))-height*.2)),x1:Math.min(width,Math.ceil(Math.max(...aligned.map(w=>w.bbox.x1))+height*.45)),height};
    });
  }
  function rows(pixels,width,height,column){
    const {x0,x1}=column,counts=new Uint32Array(height),span=x1-x0;
    for(let y=0;y<height;y++)for(let x=x0;x<x1;x++){
      const i=(y*width+x)*4,r=pixels[i],g=pixels[i+1],b=pixels[i+2];
      // Exclude blue annotation ink; dark neutral print survives.
      if(Math.max(r,g,b)<115&&b-r<18&&b-g<22)counts[y]++;
    }
    const bands=[];let start=-1,last=-1;
    for(let y=0;y<=height;y++){
      const active=y<height&&counts[y]>Math.max(5,span*.025)&&counts[y]<span*.8;
      if(active){if(start<0)start=y;last=y}
      if(start>=0&&(!active&&(y-last>3)||y===height)){
        const h=last-start+1;
        if(h>=Math.max(10,column.height*.65)&&h<=column.height*2){const pad=Math.max(4,Math.round(column.height*.15));bands.push({x:x0,y:Math.max(0,start-pad),w:span,h:Math.min(height,last+pad+1)-Math.max(0,start-pad)})}
        start=-1;
      }
    }
    return bands;
  }
  function clean(pixels){
    const output=new Uint8ClampedArray(pixels.length);
    for(let i=0;i<pixels.length;i+=4){const r=pixels[i],g=pixels[i+1],b=pixels[i+2];const v=Math.max(r,g,b)<115&&b-r<18&&b-g<22?0:255;output[i]=output[i+1]=output[i+2]=v;output[i+3]=255}return output;
  }
  const api={columns,rows,clean};if(typeof module!=='undefined')module.exports=api;else root.OCRLayout=api;
})(globalThis);
