const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const STORE='shici_words_v1';
let words=JSON.parse(localStorage.getItem(STORE)||'[]'), current=null, queue=[], queueIndex=0;
const builtins={
  encounter:{part:'verb',phonetic:'/ɪnˈkaʊntə(r)/',meaning:'偶然遇到；遭遇',sceneEn:'You encounter an unfamiliar word in the middle of a reading passage.',sceneZh:'想象你读到文章中间，偶然遇见一个陌生词。'},
  sustain:{part:'verb',phonetic:'/səˈsteɪn/',meaning:'维持；支撑',sceneEn:'A small daily habit can sustain your progress for months.',sceneZh:'想象一个很小的每日习惯，持续支撑着你几个月的进步。'},
  compelling:{part:'adjective',phonetic:'/kəmˈpelɪŋ/',meaning:'引人入胜的；令人信服的',sceneEn:'Her product story is so compelling that everyone leans closer.',sceneZh:'想象她讲产品故事时，所有人都被吸引得向前靠近。'},
  emerge:{part:'verb',phonetic:'/ɪˈmɜːdʒ/',meaning:'出现；显露',sceneEn:'A clear idea begins to emerge from a page of messy sketches.',sceneZh:'想象一张凌乱草图中，清晰的想法慢慢显现出来。'},
  reluctant:{part:'adjective',phonetic:'/rɪˈlʌktənt/',meaning:'不情愿的；勉强的',sceneEn:'She is reluctant to open a list crowded with hundreds of words.',sceneZh:'想象她看到挤满几百个词的列表，迟迟不愿点开。'}
};
function showView(id){$$('.view').forEach(v=>v.classList.toggle('active',v.id===id));$$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===id));if(id==='reviewView')startReview();if(id==='libraryView')renderLibrary();}
$$('.nav-item').forEach(b=>b.onclick=()=>showView(b.dataset.view));
function speak(word,audio){if(audio){new Audio(audio).play().catch(()=>speech(word));}else speech(word)}
function speech(word){speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(word);u.lang='en-US';u.rate=.82;speechSynthesis.speak(u)}
function cleanWords(text){return [...new Set((text.replace(/[’‘]/g,"'").match(/[A-Za-z]+(?:['-][A-Za-z]+)*/g)||[]).map(w=>w.toLowerCase()))].filter(w=>w.length>1&&w.length<46)}
function showManual(){$('#manualForm').classList.remove('hidden');$('#nativeHint').classList.remove('hidden');$('#manualInput').focus()}
function showCandidates(list,uncertain=[]){
  $('#candidateNote').textContent='';
  $('#scanState').classList.add('hidden');
  $('#uncertainPanel').classList.toggle('hidden',!uncertain.length);$('#uncertainPanel').open=false;$('#uncertainCount').textContent=`待核对（${uncertain.length}）`;$('#uncertainWords').replaceChildren(...uncertain.map(w=>{const b=document.createElement('button');b.type='button';b.textContent=w.text;b.onclick=()=>{showManual();$('#manualInput').value=w.text;$('#nativeHint').textContent='这个结果未通过可靠识别或词典校验，请对照原图后再继续。'};return b}));
  if(!list.length&&!uncertain.length){showManual();return}
  $('#wordChips').replaceChildren(...list.map(w=>{const b=document.createElement('button');b.type='button';b.textContent=typeof w==='string'?w:w.text;if(w.uncertain){b.classList.add('uncertain');b.title='识别不确定，请核对原图';b.setAttribute('aria-label',w.text+'，请核对')}b.onclick=()=>openWord(typeof w==='string'?w:w.text);return b}));
  $('#resultPanel').classList.remove('hidden');
}
$('#manualStart').onclick=$('#manualToggle').onclick=showManual;
$('#manualForm').onsubmit=e=>{e.preventDefault();const list=cleanWords($('#manualInput').value);if(list.length===1)openWord(list[0]);else showCandidates(list)};
let photo=null,selection=null,dragStart=null,ocrLoading=null,scanJob=null;
const canvas=$('#cropCanvas'),ctx=canvas.getContext('2d');
function drawCrop(){if(!photo)return;ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(photo,0,0,canvas.width,canvas.height);if(selection){const {x,y,w,h}=selection;ctx.fillStyle='rgba(0,0,0,.45)';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(photo,x/canvas.width*photo.naturalWidth,y/canvas.height*photo.naturalHeight,w/canvas.width*photo.naturalWidth,h/canvas.height*photo.naturalHeight,x,y,w,h);ctx.strokeStyle='#e8ff6b';ctx.lineWidth=3;ctx.strokeRect(x,y,w,h)}}
function point(e){const r=canvas.getBoundingClientRect();return {x:Math.max(0,Math.min(canvas.width,(e.clientX-r.left)*canvas.width/r.width)),y:Math.max(0,Math.min(canvas.height,(e.clientY-r.top)*canvas.height/r.height))}}
canvas.onpointerdown=e=>{if(!photo||scanJob)return;dragStart=point(e);canvas.setPointerCapture(e.pointerId)};
canvas.onpointermove=e=>{if(!dragStart)return;const p=point(e);selection={x:Math.min(p.x,dragStart.x),y:Math.min(p.y,dragStart.y),w:Math.abs(p.x-dragStart.x),h:Math.abs(p.y-dragStart.y)};if(selection.w&&selection.h)drawCrop()};
canvas.onpointerup=canvas.onpointercancel=()=>{dragStart=null;if(selection&&(selection.w<8||selection.h<8))selection=null;drawCrop()};
$('#resetCrop').onclick=()=>{selection=null;drawCrop()};
$('#cameraInput').onchange=async e=>{
  const file=e.target.files[0];if(!file)return;
  const url=URL.createObjectURL(file),img=new Image();
  img.onload=()=>{photo=img;selection=null;canvas.width=900;canvas.height=Math.round(900*img.naturalHeight/img.naturalWidth);drawCrop();$('#cropPanel').classList.remove('hidden');$('#resultPanel').classList.add('hidden');URL.revokeObjectURL(url);runScan()};
  img.onerror=()=>{URL.revokeObjectURL(url);showManual()};img.src=url;e.target.value='';
};
let dictionaryPromise;
function loadDictionary(){if(!dictionaryPromise)dictionaryPromise=Promise.all(['index.aff','index.dic'].map(async name=>{const r=await fetch('vendor/dictionary/'+name,{signal:AbortSignal.timeout(30000)});if(!r.ok)throw Error('dictionary');return r.text()})).then(([aff,dic])=>new NSpell(aff,dic)).catch(e=>{dictionaryPromise=null;throw e});return dictionaryPromise}
function loadOCR(){
  if(window.Tesseract)return Promise.resolve();
  if(ocrLoading)return ocrLoading;
  ocrLoading=new Promise((resolve,reject)=>{const script=document.createElement('script');const timer=setTimeout(()=>{script.remove();reject(Error('timeout'))},15000);script.src='vendor/ocr/tesseract.min.js?v=4';script.onload=()=>{clearTimeout(timer);resolve()};script.onerror=()=>{clearTimeout(timer);script.remove();reject(Error('network'))};document.head.append(script)}).catch(e=>{ocrLoading=null;throw e});return ocrLoading;
}
function makeCrop(source,region,clean=false){
  const out=document.createElement('canvas');out.width=region.w+40;out.height=region.h+40;
  const c=out.getContext('2d');c.fillStyle='white';c.fillRect(0,0,out.width,out.height);c.drawImage(source,region.x,region.y,region.w,region.h,20,20,region.w,region.h);
  if(clean){const image=c.getImageData(0,0,out.width,out.height);image.data.set(OCRLayout.clean(image.data));c.putImageData(image,0,0)}return out;
}
function setBusy(value){['recognizeBtn','cameraInput','resetCrop'].forEach(id=>$('#'+id).disabled=value);$('#cancelScan').classList.toggle('hidden',!value)}
$('#cancelScan').onclick=()=>{if(scanJob){scanJob.cancelled=true;scanJob.reject?.(Error('cancelled'));scanJob.worker?.terminate();$('#scanText').textContent='正在停止…'}};
async function runScan(){
  if(!photo||scanJob)return;
  const job={cancelled:false,worker:null};scanJob=job;setBusy(true);
  $('#scanState').classList.remove('hidden');$('#resultPanel').classList.add('hidden');$('#scanText').textContent='正在准备识别…';
  let timer;
  const check=()=>{if(job.cancelled)throw Error('cancelled')};
  const work=async()=>{
    await loadOCR();const spell=await loadDictionary();check();
    const worker=await Tesseract.createWorker('eng',1,{workerPath:new URL('vendor/ocr/worker.min.js',location.href).href,corePath:new URL('vendor/ocr/',location.href).href,langPath:new URL('vendor/ocr',location.href).href,gzip:false,cachePath:'shici-eng-v4',errorHandler:()=>{},logger:m=>{if(!job.cancelled&&m.status==='loading language traineddata')$('#scanText').textContent='首次使用，正在下载英文识别模型…'}});job.worker=worker;
    if(job.cancelled){await worker.terminate();check()}
    const region=selection||{x:0,y:0,w:canvas.width,h:canvas.height};
    const source=document.createElement('canvas');
    const sw=region.w/canvas.width*photo.naturalWidth,sh=region.h/canvas.height*photo.naturalHeight;
    const scale=Math.min(1,2400/Math.max(sw,sh));source.width=Math.max(1,Math.round(sw*scale));source.height=Math.max(1,Math.round(sh*scale));
    source.getContext('2d').drawImage(photo,region.x/canvas.width*photo.naturalWidth,region.y/canvas.height*photo.naturalHeight,sw,sh,0,0,source.width,source.height);
    $('#scanText').textContent='正在查找英文区域…';
    await worker.setParameters({tessedit_pageseg_mode:'11'});
    const first=(await worker.recognize(source)).data;check();
    const seed=first.words||[];
    const pixels=source.getContext('2d').getImageData(0,0,source.width,source.height).data;
    const columns=OCRLayout.columns(seed.filter(w=>spell.correct(w.text.toLowerCase())),source.width);
    let regions=columns.flatMap(c=>OCRLayout.rows(pixels,source.width,source.height,c));
    // A close-up or passage may have no repeated word column. Use detected text lines.
    if(!regions.length)regions=(first.lines||[]).filter(l=>/[A-Za-z]{2}/.test(l.text)).map(l=>({x:Math.max(0,l.bbox.x0-5),y:Math.max(0,l.bbox.y0-5),w:Math.min(source.width,l.bbox.x1+5)-Math.max(0,l.bbox.x0-5),h:Math.min(source.height,l.bbox.y1+5)-Math.max(0,l.bbox.y0-5)}));
    const limited=regions.length>60;regions=regions.slice(0,60);
    if(!regions.length)regions=[{x:0,y:0,w:source.width,h:source.height}];
    const candidates=new Map();
    for(let i=0;i<regions.length;i++){
      check();$('#scanText').textContent=`正在识别第 ${i+1} / ${regions.length} 行…`;
      await worker.setParameters({tessedit_pageseg_mode:regions.length===1&&regions[0].h>regions[0].w?'6':'7'});
      const original=(await worker.recognize(makeCrop(source,regions[i]))).data;check();
      const cleaned=(await worker.recognize(makeCrop(source,regions[i],true))).data;check();
      const entries=OCRPolicy.collect([original,cleaned],spell);
      for(const entry of entries){
        const previous=candidates.get(entry.text);
        if(!previous||(!entry.uncertain&&previous.uncertain)||entry.confidence>previous.confidence&&entry.uncertain===previous.uncertain)candidates.set(entry.text,entry);
      }
    }
    check();const all=[...candidates.values()],list=all.filter(w=>!w.uncertain),uncertain=all.filter(w=>w.uncertain);showCandidates(list,uncertain);
    $('#candidateNote').textContent=limited?'这次处理了前 60 行；剩余部分可框选后继续识别。':uncertain.length?'不确定的结果已收起，可展开对照原图。':'点选生词；有遗漏时可在原图框选后重试。';
    if(!list.length){$('#nativeHint').textContent='没有找到清晰的英文。可框选生词重试，或粘贴 iPhone 实况文本。'}
  };
  try{await Promise.race([work(),new Promise((_,reject)=>{job.reject=reject;timer=setTimeout(()=>{job.cancelled=true;reject(Error('timeout'))},120000)})])}
  catch{job.cancelled=true;$('#scanState').classList.add('hidden');$('#candidateNote').textContent='';showManual();$('#nativeHint').textContent='识别已停止或资源加载未完成。可框选更小的区域重试，也可以粘贴 iPhone 实况文本；不会把未校验的乱码当成单词。'}
  finally{clearTimeout(timer);await job.worker?.terminate().catch(()=>{});if(scanJob===job){scanJob=null;setBusy(false)}}
}
$('#recognizeBtn').onclick=runScan;
const lexicalFields=['part','phonetic','meaning','sceneEn','sceneZh','audio','lookupStatus','source'];
function persistWords(){localStorage.setItem(STORE,JSON.stringify(words))}
function updateSaved(entry){const saved=words.find(w=>w.word===entry.word);if(!saved)return;for(const key of lexicalFields)if(entry[key]!==undefined)saved[key]=entry[key];persistWords();if($('#libraryView').classList.contains('active'))renderLibrary()}
async function openWord(word){
  word=word.toLowerCase().trim();
  const saved=words.find(w=>w.word===word);
  current={word,part:'word',phonetic:'',meaning:'正在获取释义…',sceneEn:'',sceneZh:'',audio:'',createdAt:Date.now(),nextReview:Date.now(),level:0,...saved};
  paintWord();showView('wordView');speak(word);await lookup(word);
}
function paintWord(){
  $('#wordTitle').textContent=current.word;$('#part').textContent=current.part;$('#phonetic').textContent=current.phonetic||'轻点右侧听读音';$('#meaning').textContent=current.meaning;
  $('#sceneEn').textContent=current.sceneEn||'';$('#sceneZh').textContent=current.sceneZh||'';
  $('#sceneBlock').classList.toggle('hidden',!current.sceneEn);
}
async function lookup(word){
  const target=current;target.lookupStatus='loading';$('#saveBtn').disabled=true;$('#retryLookup').classList.add('hidden');$('#lookupState').classList.remove('hidden');$('#lookupState').textContent='正在寻找释义和例句…';
  try{
    const entry=builtins[word]||await WordLookup.find(word);
    if(!entry)throw Error('missing');
    Object.assign(target,entry,{lookupStatus:'ready'});updateSaved(target);
    if(current===target){paintWord();$('#lookupState').textContent=entry.sceneEn?'':'已找到释义，词典暂未提供例句。';$('#lookupState').classList.toggle('hidden',!!entry.sceneEn)}
  }catch(error){
    if(current!==target)return;
    const hasSaved=target.source&&target.meaning&&!/正在|暂未/.test(target.meaning);
    if(!hasSaved)Object.assign(target,{lookupStatus:'unavailable',meaning:['missing','missing-offline'].includes(error.message)?'词库暂未收录这个词':'词库文件未能加载，请重试',sceneEn:'',sceneZh:''});
    else target.lookupStatus='ready';
    paintWord();$('#lookupState').textContent=error.message==='missing-offline'?'本地未收录，在线补充查询也未连接成功。可以稍后重试。':error.message==='missing'?'本地和在线词典均未查到，可以返回核对拼写。':'词库下载未完成。请检查连接后重试，已有收藏会保留。';$('#lookupState').classList.remove('hidden');$('#retryLookup').classList.remove('hidden');
  }finally{if(current===target)$('#saveBtn').disabled=false}
}
$('#retryLookup').onclick=()=>lookup(current.word);
$('#soundBtn').onclick=()=>speak(current.word,current.audio);$('#backBtn').onclick=$('#skipBtn').onclick=()=>showView('captureView');
$('#saveBtn').onclick=()=>{if(!current||current.lookupStatus==='loading')return;const old=words.findIndex(w=>w.word===current.word);if(old>=0)words[old]={...words[old],...current};else words.unshift({...current});persistWords();$('#saveBtn').textContent='收好了';navigator.vibrate?.(35);setTimeout(()=>{$('#saveBtn').textContent='留下这个词';if($('#wordView').classList.contains('active'))showView('captureView')},550)};
function dueWords(){return words.filter(w=>(w.nextReview||0)<=Date.now()).slice(0,5)}
function startReview(){queue=dueWords();queueIndex=0;if(!queue.length){$('#reviewEmpty').classList.remove('hidden');$('#reviewCard').classList.add('hidden');$('#reviewSummary').textContent='没有欠下的任务。'}else{$('#reviewEmpty').classList.add('hidden');$('#reviewCard').classList.remove('hidden');$('#reviewSummary').textContent=`今天 ${queue.length} 个，不追赶欠下的进度。`;paintReview()}}
function paintReview(){const w=queue[queueIndex];$('#reviewCount').textContent=`${queueIndex+1} / ${queue.length}`;$('#reviewWord').textContent=w.word;$('#reviewPhonetic').textContent=w.phonetic||'';$('#reviewMeaning').textContent=w.lookupStatus==='ready'?w.meaning:'释义待补全，可在收藏中点开重试';$('#reviewScene').textContent=[w.sceneEn,w.sceneZh].filter(Boolean).join('\n');$('#reviewAnswer').classList.add('hidden');$('#revealBtn').classList.remove('hidden');$('#reviewDots').textContent='•'.repeat(queue.length)}
$('#revealBtn').onclick=()=>{$('#reviewAnswer').classList.remove('hidden');$('#revealBtn').classList.add('hidden')};$('#reviewSound').onclick=()=>{const w=queue[queueIndex];speak(w.word,w.audio)};
$$('[data-rating]').forEach(b=>b.onclick=()=>{const w=queue[queueIndex],days=b.dataset.rating==='easy'?Math.max(3,(w.level||0)*3+3):b.dataset.rating==='hard'?1:0;w.level=b.dataset.rating==='again'?0:(w.level||0)+1;w.nextReview=Date.now()+days*86400000+(days===0?10*60000:0);const i=words.findIndex(x=>x.word===w.word);words[i]=w;localStorage.setItem(STORE,JSON.stringify(words));queueIndex++;if(queueIndex>=queue.length)startReview();else paintReview()});
function renderLibrary(){
  $('#libraryCount').textContent=`${words.length} 个`;$('#libraryEmpty').classList.toggle('hidden',words.length>0);
  $('#wordList').replaceChildren(...words.map(w=>{
    const row=document.createElement('div');row.className='list-item';
    const details=document.createElement('button');details.className='word-details';details.onclick=()=>openWord(w.word);
    const title=document.createElement('strong');title.textContent=w.word;
    const meaning=document.createElement('p');meaning.textContent=w.lookupStatus==='ready'?w.meaning:'点开补全释义和例句';details.append(title,meaning);
    const sound=document.createElement('button');sound.className='list-sound';sound.textContent='♪';sound.setAttribute('aria-label','播放 '+w.word);sound.onclick=()=>speak(w.word,w.audio);
    row.append(details,sound);return row;
  }));
}
// Repair previously saved placeholders without changing review dates or progress.
async function repairSavedWords(){
  // Load only saved words' shards, limiting simultaneous downloads.
  const snapshot=[...words];
  for(let offset=0;offset<snapshot.length;offset+=4){
    await Promise.allSettled(snapshot.slice(offset,offset+4).map(async saved=>{
      const entry=builtins[saved.word]||WordLookup.local(await WordLookup.load(saved.word),saved.word);
      if(entry)updateSaved({...entry,word:saved.word,lookupStatus:'ready'});
    }));
  }
  if($('#reviewView').classList.contains('active')&&queue.length)paintReview();
}
repairSavedWords().catch(()=>{});
$('#helpBtn').onclick=()=>$('#helpDialog').showModal();$('#closeHelp').onclick=()=>$('#helpDialog').close();
if('serviceWorker'in navigator)navigator.serviceWorker.register('sw.js');
